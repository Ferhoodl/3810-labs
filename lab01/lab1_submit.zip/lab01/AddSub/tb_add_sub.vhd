-------------------------------------------------------------------------
-- Isaiah Steele
-- Student in CprE 3810
-- Iowa State University
-------------------------------------------------------------------------
-- tb_adder_n.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: This file contains a testbench for an n-bit ripple-carry
-- adder.
--              
-- 09/08/2026: created
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_textio.all;  -- For logic types I/O
library std;
use std.env.all;                -- For hierarchical/external signals
use std.textio.all;             -- For basic I/O

entity tb_add_sub is
  generic(
  gCLK_HPER   : time := 10 ns;   -- Generic for half of the clock cycle period
  N           : integer := 32);
end tb_add_sub;



architecture mixed of tb_add_sub is

-- Define the total clock period time
constant cCLK_PER  : time := gCLK_HPER * 2;

-- We will be instantiating our design under test (DUT), so we need to specify its
-- component interface.
-- TODO: change component declaration as needed.
component add_sub is
  generic(N : integer := 32); -- Generic of type integer for input/output data width. Default value is 32.
  port(i_A         : in std_logic_vector(N-1 downto 0);
       i_B         : in std_logic_vector(N-1 downto 0);
       i_C         : in std_logic;
       o_S        : out std_logic_vector(N-1 downto 0);
       o_C        : out std_logic);
end component;

signal s_i_A   : std_logic_vector(N-1 downto 0);
signal s_i_B   : std_logic_vector(N-1 downto 0);
signal s_i_C    : std_logic := '0';
signal s_o_S    : std_logic_vector(N-1 downto 0);
signal s_o_C    : std_logic := '0';


begin

  -- TODO: Actually instantiate the component to test and wire all signals to the corresponding
  -- input or output. Note that DUT0 is just the name of the instance that can be seen 
  -- during simulation. What follows DUT0 is the entity name that will be used to find
  -- the appropriate library component during simulation loading.
  DUT0: add_sub
  generic map(
    N => N)
  port map( i_A        => s_i_A,
            i_B        => s_i_B,
            i_C        => s_i_C,
            o_S        => s_o_S,
            o_C        => s_o_C);
  --You can also do the above port map in one line using the below format: http://www.ics.uci.edu/~jmoorkan/vhdlref/compinst.html

  -- Assign inputs for each test case.
  -- TODO: add test cases as needed.
  P_TEST_CASES: process
  begin
    wait for gCLK_HPER*2;


    -- Test case 0:
    s_i_A <= x"00000000";
    s_i_B <= x"00000000";
    s_i_C <= '0';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 1:
    s_i_A <= x"00000001";
    s_i_B <= x"00000001";
    s_i_C <= '0';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 2:
    s_i_A <= x"00000001";
    s_i_B <= x"00000001";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 3:
    s_i_A <= x"00000000";
    s_i_B <= x"00000001";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 4:
    s_i_A <= x"0000000A";
    s_i_B <= x"0000000A";
    s_i_C <= '0';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 5:
    s_i_A <= x"0000000A";
    s_i_B <= x"0000000A";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 6:
    s_i_A <= x"0000000A";
    s_i_B <= x"0000000F";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 7:
    s_i_A <= x"0000000F";
    s_i_B <= x"0000000A";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 8:
    s_i_A <= x"FFFFFFFF";
    s_i_B <= x"0000FFFF";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 9:
    s_i_A <= x"0000FFFF";
    s_i_B <= x"FFFFFFFF";
    s_i_C <= '1';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 10:
    s_i_A <= x"FFFFFFFF";
    s_i_B <= x"00000001";
    s_i_C <= '0';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;

    -- Test case 11:
    s_i_A <= x"FFFFFFFF";
    s_i_B <= x"FFFFFFFF";
    s_i_C <= '0';
    wait for gCLK_HPER*2;
    wait for gCLK_HPER*2;


    wait;
  end process;

end mixed;
