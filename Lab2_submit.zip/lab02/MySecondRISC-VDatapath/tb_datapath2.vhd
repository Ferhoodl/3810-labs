-------------------------------------------------------------------------
-- Isaiah Steele
-- Student in CprE 3810
-- Iowa State University
-------------------------------------------------------------------------


-- tb_datapath2.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: This file contains a testbench for a datapath.
--              
-- 09/21/2026: created
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_textio.all;  -- For logic types I/O
library std;
use std.env.all;                -- For hierarchical/external signals
use std.textio.all;             -- For basic I/O

entity tb_datapath2 is
  generic(
  gCLK_HPER   : time := 10 ns;   -- Generic for half of the clock cycle period
  N           : integer := 32);
end tb_datapath2;



architecture structure of tb_datapath2 is

-- Define the total clock period time
constant cCLK_PER  : time := gCLK_HPER * 2;

component datapath2 is
  generic(N : integer := 32); -- Generic of type integer for input/output data width. Default value is 32.
  port(i_CLK         : in std_logic;                            -- Clock input              X
       i_RST         : in std_logic;                            --                          X
       i_rd          : in std_logic_vector(4 downto 0);         -- 5-bit write address      X
       i_regWrite    : in std_logic;                            -- line for write enable    X
       i_memWrite    : in std_logic;                            -- memory write enble       X
       i_rs1         : in std_logic_vector(4 downto 0);         -- 5-bit read address A     X
       i_rs2         : in std_logic_vector(4 downto 0);         -- 5-bit read address B     X
       i_20_imm      : in std_logic_vector(19 downto 0);        --                          X
       i_12_imm      : in std_logic_vector(11 downto 0);        --                          X
       i_AddSub      : in std_logic;                            --                          X
       i_ALUSrc      : in std_logic;                            --                          X
       i_imm_sel     : in std_logic;                            --                          X
       i_memToReg    : in std_logic);
end component;

signal tb_i_CLK       : std_logic;                            -- Clock input
signal tb_i_RST       : std_logic;                            -- line for reset
signal tb_i_rd        : std_logic_vector(4 downto 0);         -- 5-bit write address
signal tb_i_regWrite  : std_logic;                            -- line for write enable
signal tb_i_memWrite  : std_logic;
signal tb_i_rs1       : std_logic_vector(4 downto 0);         -- 5-bit read address A
signal tb_i_rs2       : std_logic_vector(4 downto 0);         -- 5-bit read address B
signal tb_i_20_imm    : std_logic_vector(19 downto 0);        -- 32-bit write value
signal tb_i_12_imm    : std_logic_vector(11 downto 0);        -- 32-bit write value
signal tb_i_AddSub    : std_logic;                            -- 32-bit read value A
signal tb_i_ALUSrc    : std_logic;                            -- 32-bit read value B
signal tb_i_imm_sel   : std_logic;
signal tb_i_memToReg  : std_logic;


begin

  -- TODO: Actually instantiate the component to test and wire all signals to the corresponding
  -- input or output. Note that DUT0 is just the name of the instance that can be seen 
  -- during simulation. What follows DUT0 is the entity name that will be used to find
  -- the appropriate library component during simulation loading.
  DUT0: datapath2
  generic map(
    N => N)
  port map( 
       i_CLK        => tb_i_CLK,
       i_RST        => tb_i_RST,
       i_rd         => tb_i_rd,
       i_regWrite   => tb_i_regWrite,
       i_memWrite   => tb_i_memWrite,
       i_rs1        => tb_i_rs1,
       i_rs2        => tb_i_rs2,
       i_20_imm     => tb_i_20_imm,
       i_12_imm     => tb_i_12_imm,
       i_AddSub     => tb_i_AddSub,
       i_ALUSrc     => tb_i_ALUSrc,
       i_imm_sel    => tb_i_imm_sel,
       i_memToReg   => tb_i_memToReg);

--This first process is to setup the clock for the test bench
  P_CLK: process
  begin
    tb_i_CLK <= '1';         -- clock starts at 1
    wait for gCLK_HPER; -- after half a cycle
    tb_i_CLK <= '0';         -- clock becomes a 0 (negative edge)
    wait for gCLK_HPER; -- after half a cycle, process begins evaluation again
  end process;


  -- Assign inputs for each test case.
  -- TODO: add test cases as needed.
  P_TEST_CASES: process
  begin
    wait for gCLK_HPER/2; -- helps to remove ambiguous edges

    -- setup
    tb_i_RST        <= '1';
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '0';
    tb_i_rs2        <= "00000"; 
    wait for cCLK_PER*2;
    
    tb_i_RST        <= '0';
    wait for cCLK_PER;

    -- lui x25, 0x10010  (# Initialize x25 to 0x10010000)
    tb_i_rd         <= "11001";              -- x25
    tb_i_rs1        <= "00000";              -- zero
    tb_i_rs2        <= "00000";             
    tb_i_20_imm     <= x"10010";             -- 20-bit immediate
    tb_i_imm_sel    <= '0';                  -- 0-append for upper immediate
    tb_i_ALUSrc     <= '1';                  -- Use immediate
    tb_i_AddSub     <= '0';                  -- Add
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- addi x25, x25, 0  (# Load &A into x25, offset 0)
    tb_i_rd         <= "11001";              -- x25
    tb_i_rs1        <= "11001";              -- x25
    tb_i_12_imm     <= x"000";               -- 12-bit immediate 0
    tb_i_imm_sel    <= '1';                  -- Sign extend
    tb_i_ALUSrc     <= '1';
    tb_i_AddSub     <= '0';
    tb_i_regWrite   <= '1';
    wait for cCLK_PER;

    -- addi x26, zero, 256 (# Load &B into x26, 256 = 0x100)
    tb_i_rd         <= "11010";              -- x26
    tb_i_rs1        <= "00000";              -- zero
    tb_i_12_imm     <= x"100";              -- 256 in hex
    tb_i_imm_sel    <= '1';
    tb_i_ALUSrc     <= '1';
    tb_i_AddSub     <= '0';
    tb_i_regWrite   <= '1';
    wait for cCLK_PER;

    -- lw x1, 0(x25)
    tb_i_rd         <= "00001";              -- x1
    tb_i_rs1        <= "11001";              -- x25
    tb_i_12_imm     <= x"000";
    tb_i_imm_sel    <= '1';
    tb_i_ALUSrc     <= '1';
    tb_i_AddSub     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';                  -- Load from memory
    wait for cCLK_PER;

    -- lw x2, 4(x25)
    tb_i_rd         <= "00010";              -- x2
    tb_i_rs1        <= "11001";              -- x25
    tb_i_12_imm     <= x"004";               -- Offset 4 for A[1]
    tb_i_imm_sel    <= '1';                  -- Sign extend
    tb_i_ALUSrc     <= '1';                  -- Use immediate
    tb_i_AddSub     <= '0';                  -- Add
    tb_i_regWrite   <= '1';                  -- Enable reg write
    tb_i_memWrite   <= '0';                  -- Disable mem write
    tb_i_memToReg   <= '1';                  -- Load from memory
    wait for cCLK_PER;

    -- add x1, x1, x2
    tb_i_rd         <= "00001";              -- x1
    tb_i_rs1        <= "00001";              -- x1
    tb_i_rs2        <= "00010";              -- x2
    tb_i_ALUSrc     <= '0';                  -- Use register B
    tb_i_AddSub     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';                  -- ALU result
    wait for cCLK_PER;

    -- sw x1, 0(x26)
    tb_i_rs1        <= "11010";              -- x26 (base)
    tb_i_rs2        <= "00001";              -- x1 (data to store)
    tb_i_12_imm     <= x"000";
    tb_i_ALUSrc     <= '1';                  -- Use immediate for address
    tb_i_regWrite   <= '0';                  -- No reg write on store
    tb_i_memWrite   <= '1';                  -- Enable memory write
    wait for cCLK_PER;

    -- lw x2, 8(x25)
    tb_i_rd         <= "00010";
    tb_i_rs1        <= "11001";
    tb_i_12_imm     <= x"008";
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';
    wait for cCLK_PER;

    -- add x1, x1, x2
    tb_i_rd         <= "00001";
    tb_i_rs1        <= "00001";
    tb_i_rs2        <= "00010";
    tb_i_ALUSrc     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- sw x1, 4(x26)
    tb_i_rs1        <= "11010";
    tb_i_rs2        <= "00001";
    tb_i_12_imm     <= x"004";
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '1';
    wait for cCLK_PER;

    -- lw x2, 12(x25)
    tb_i_rd         <= "00010";
    tb_i_rs1        <= "11001";
    tb_i_12_imm     <= x"00C";
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';
    wait for cCLK_PER;

    -- add x1, x1, x2
    tb_i_rd         <= "00001";
    tb_i_rs1        <= "00001";
    tb_i_rs2        <= "00010";
    tb_i_ALUSrc     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- sw x1, 8(x26)
    tb_i_rs1        <= "11010";
    tb_i_rs2        <= "00001";
    tb_i_12_imm     <= x"008";
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '1';
    wait for cCLK_PER;

    -- lw x2, 16(x25)
    tb_i_rd         <= "00010";
    tb_i_rs1        <= "11001";
    tb_i_12_imm     <= x"010";
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';
    wait for cCLK_PER;

    -- add x1, x1, x2
    tb_i_rd         <= "00001";
    tb_i_rs1        <= "00001";
    tb_i_rs2        <= "00010";
    tb_i_ALUSrc     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- sw x1, 12(x26)
    tb_i_rs1        <= "11010";
    tb_i_rs2        <= "00001";
    tb_i_12_imm     <= x"00C";
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '1';
    wait for cCLK_PER;

    -- lw x2, 20(x25)
    tb_i_rd         <= "00010";
    tb_i_rs1        <= "11001";
    tb_i_12_imm     <= x"014";
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';
    wait for cCLK_PER;

    -- add x1, x1, x2
    tb_i_rd         <= "00001";
    tb_i_rs1        <= "00001";
    tb_i_rs2        <= "00010";
    tb_i_ALUSrc     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- sw x1, 16(x26)
    tb_i_rs1        <= "11010";
    tb_i_rs2        <= "00001";
    tb_i_12_imm     <= x"010";
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '1';
    wait for cCLK_PER;

    -- lw x2, 24(x25)
    tb_i_rd         <= "00010";
    tb_i_rs1        <= "11001";
    tb_i_12_imm     <= x"018";
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';
    wait for cCLK_PER;

    -- add x1, x1, x2
    tb_i_rd         <= "00001";
    tb_i_rs1        <= "00001";
    tb_i_rs2        <= "00010";
    tb_i_ALUSrc     <= '0';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- addi x27, zero, 512 (# Load &B[64] into x27, 512 = 0x200)
    tb_i_rd         <= "11011";              -- x27
    tb_i_rs1        <= "00000";
    tb_i_12_imm     <= x"200";
    tb_i_imm_sel    <= '1';
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '1';
    tb_i_memToReg   <= '0';
    wait for cCLK_PER;

    -- sw x1, -4(x27)
    tb_i_rs1        <= "11011";              -- x27
    tb_i_rs2        <= "00001";              -- x1
    tb_i_12_imm     <= x"FFC";               -- -4 in two's complement
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '1';
    wait for cCLK_PER;

    -- lw x1, -4(x27)
    tb_i_rd         <= "00001";
    tb_i_rs1        <= "11011";
    tb_i_12_imm     <= x"FFC";
    tb_i_ALUSrc     <= '1';
    tb_i_regWrite   <= '1';
    tb_i_memWrite   <= '0';
    tb_i_memToReg   <= '1';
    wait for cCLK_PER;

    -- End of simulation
    tb_i_regWrite   <= '0';
    tb_i_memWrite   <= '0';
    wait for cCLK_PER * 2;

    tb_i_regWrite <= '0';
    wait for cCLK_PER;


    wait;
  end process;

end structure;